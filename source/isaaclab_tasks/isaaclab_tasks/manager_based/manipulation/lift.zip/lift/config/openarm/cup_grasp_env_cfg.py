# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Stage 2 — Cup Grasp: train the robot to close the gripper around the cup and lift it slightly.

Success condition: object z-height > 0.09 m (slightly above table top).
The gripper_closed_reward acts as a proxy for actual contact since no contact sensor is required.
"""

from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.utils import configclass

from isaaclab_tasks.manager_based.manipulation.lift import mdp
from isaaclab_tasks.manager_based.manipulation.lift.config.openarm.joint_pos_env_cfg import OpenArmCubeLiftEnvCfg

##
# Reward configuration
##


@configclass
class CupGraspRewardsCfg:
    """Rewards for Stage 2: grasp the cup."""

    # Keep EE near the cup so the agent doesn't wander
    reaching_object = RewTerm(func=mdp.object_ee_distance, params={"std": 0.1}, weight=1.0)

    # Orientation: force horizontal (flat) alignment to align with cup body
    ee_align = RewTerm(func=mdp.ee_align_cup_grasp_flat, weight=2.0)

    # Encourage gripper closure (proxy for grasping), but ONLY when close to the cup
    gripper_closed = RewTerm(
        func=mdp.gripper_closed_near_object_reward,
        params={
            "robot_cfg": SceneEntityCfg("robot", joint_names=["openarm_finger_joint.*"]),
            "open_val": 0.044,
            "threshold": 0.05,
        },
        weight=3.0,
    )

    # Bonus for actually lifting the cup off the table
    lifting_object = RewTerm(func=mdp.object_is_lifted, params={"minimal_height": 0.09}, weight=12.0)

    # Keep the cup upright while grasping
    object_tilt = RewTerm(func=mdp.object_tilt_penalty, params={"tilt_angle_limit": 45.0}, weight=-2.0)

    # Regularisation
    action_rate = RewTerm(func=mdp.action_rate_l2, weight=-1e-4)
    joint_vel = RewTerm(
        func=mdp.joint_vel_l2,
        weight=-1e-4,
        params={"asset_cfg": SceneEntityCfg("robot", joint_names=["openarm_joint.*", "openarm_finger_joint.*"])},
    )


##
# Termination configuration
##


@configclass
class CupGraspTerminationsCfg:
    """Terminations for Stage 2."""

    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    object_dropping = DoneTerm(
        func=mdp.root_height_below_minimum,
        params={"minimum_height": -0.05, "asset_cfg": SceneEntityCfg("object")},
    )

    # Success: cup lifted slightly off the table
    object_grasped = DoneTerm(
        func=mdp.object_grasped,
        params={"min_height": 0.09},
    )


##
# Environment configuration
##


@configclass
class CupGraspEnvCfg(OpenArmCubeLiftEnvCfg):
    """Configuration for Stage 2 — Cup Grasp."""

    def __post_init__(self):
        super().__post_init__()

        self.rewards = CupGraspRewardsCfg()
        self.terminations = CupGraspTerminationsCfg()

        # Longer episode to allow the full reach → close → lift motion
        self.episode_length_s = 10.0


@configclass
class CupGraspEnvCfg_PLAY(CupGraspEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 50
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
